
public class MeleeEnemy extends Enemy {

	public MeleeEnemy(int x, int y, int width, int height, String type, int damage, int health) {
		super(x, y, width, height, type, damage, health);
		
	}

	public String toString() {
        return "MeleeEnemy[" + getType() + "] @ (" + getX() + "," + getY() + ") "
             + getWidth() + "x" + getHeight() + " DMG=" + getDamage() + " HP=" + getHealth();
    }
	
	

}
