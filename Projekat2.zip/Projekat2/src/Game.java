import java.util.ArrayList;

public class Game {
	
	private Player player;
	private ArrayList<Enemy> enemies = new ArrayList<>();
	private ArrayList<String> eventlog = new ArrayList<>();
	
	public Game(Player player) {
		this.player = player;
	}
	public Player getPlayer() {
		return player;
	}
	public ArrayList<Enemy> getEnemies(){
		return enemies;
	}
	private ArrayList<String> getEventlog() {
		return eventlog;
	}
	

}
