
public class GameObject {
	
	private int x, y, width, height;
	

	

	public GameObject(int x, int y, int width, int height) {
		super();
		this.x = x;
		this.y = y;
		setWidth(width);
		setHeight(height);
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		if(width>0) { 
		this.width = width;
		}else {
			System.out.println("Sirina mora biti veca od 0!");
		}
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		if(height>0) { 
			this.height = height;
			}else {
				System.out.println("Visina mora biti veca od 0!");
			}
	}
	//provjeravanje kolizije
	public boolean intersects(GameObject drugi) {
		if(drugi == null) return false;
		return x < drugi.x + drugi.width && x + width > drugi.x
				&& y<drugi.y + drugi.height && y + 	height> drugi.y;
	}
	@Override
	public String toString() {
		return "GameObject @ (" + x + "," + y + ")" + width + height;
	}
	

	

	
	
	

}
