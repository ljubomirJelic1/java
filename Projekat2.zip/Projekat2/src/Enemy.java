
public class Enemy extends GameObject {
	
	private String type;
	private int damage; 
	private int health;
	public Enemy(int x, int y, int width, int height, String type, int damage, int health) {
		super(x, y, width, height);
		setType (type);
		setDamage (damage);
		setHealth (health);
		
		
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getDamage() {
		return damage;
	}
	public void setDamage(int damage) {
		if(damage >0 || damage < 100) {
			this.damage = damage;
		}else {
			System.out.println("Daamage mora biti izmedju 0 i 100!");
		}
	}
	public int getHealth() {
		return health;
	}
	public void setHealth(int health) {
		if(health >0 || health < 100) {
			this.health = health;
			}else {
				System.out.println("Health mora biti izmedju 0 i 100!");
			}
		 
	}
	@Override
	public String toString() {
		return "Enemy [" + type + "@ (" + getX() + ","+ getY() +" "+ getHeight()+"x"+getWidth()+" DMG="+ damage + " HP=" + health + "]";
	}
	public int EffectiveDamage() {
		// TODO Auto-generated method stub
		return damage;
	}
	protected int getMaxHealth() {
		// TODO Auto-generated method stub
		return 100;
	}
	
	

}
